import { useState } from "react";
import { PageHeader } from "@/components/ui";
import { ConversationList, ConversationThread } from "@/features/messaging/ConversationUI";
import { useConversationsForResident } from "@/mocks/DemoStoreContext";
import { DEMO_IDENTITIES } from "@/mocks/seed";

const RESIDENT_ID = "res-carmen"; // Ana Rivera sigue a Carmen Rivera -- identidad demo fija (sin auth todavía)

export function FamilyMessagesPage() {
  const conversations = useConversationsForResident(RESIDENT_ID);
  const [openId, setOpenId] = useState<string | null>(null);

  if (openId) {
    return (
      <ConversationThread
        conversationId={openId}
        currentParticipantId={DEMO_IDENTITIES.familyMemberId}
        currentParticipantName="Ana Rivera"
        onBack={() => setOpenId(null)}
      />
    );
  }

  return (
    <div>
      <PageHeader title="Mensajes" description="Con la cuidadora de Carmen y con administración -- por separado." />
      <ConversationList
        conversations={conversations}
        currentParticipantId={DEMO_IDENTITIES.familyMemberId}
        onOpen={setOpenId}
        emptyLabel="No tienes mensajes nuevos."
      />
    </div>
  );
}
