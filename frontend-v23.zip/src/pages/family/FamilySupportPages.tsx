import { PageHeader, EmptyState, Card, Timeline, Avatar, Button } from "@/components/ui";
import { MessageCircle, Clock3, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useCareEventsForShift, useResident, useShiftsForResident } from "@/mocks/DemoStoreContext";
import { humanizeForFamily } from "@/mocks/humanize";
import { useAuth } from "@/auth/AuthProvider";

const RESIDENT_ID = "res-carmen";

function useFamilyTimelineEntries() {
  const resident = useResident(RESIDENT_ID)!;
  const shifts = useShiftsForResident(RESIDENT_ID);
  const todayShift = shifts.find((s) => s.status !== "completed") ?? shifts[0];
  const events = useCareEventsForShift(todayShift?.id ?? "");
  return events.map((e) => ({
    id: e.id,
    time: new Date(e.createdAt).toLocaleTimeString("es-PR", { hour: "numeric", minute: "2-digit" }),
    title: humanizeForFamily(e, resident),
    tone: e.type === "incident" ? ("danger" as const) : undefined,
  }));
}

export function FamilyActivityPage() {
  const entries = useFamilyTimelineEntries();
  return (
    <div>
      <PageHeader title="Actividad" description="Lo que ha pasado hoy, en lenguaje simple." />
      {entries.length === 0 ? (
        <EmptyState icon={<Clock3 size={28} />} title="No hay actividad registrada todavía." />
      ) : (
        <Timeline entries={entries} />
      )}
    </div>
  );
}

export function FamilyProfilePage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  async function onLogout() {
    await logout();
    navigate("/login", { replace: true });
  }

  return (
    <div className="flex flex-col gap-[var(--spacing-md)]">
      <PageHeader title="Perfil" />
      <Card className="flex items-center gap-3">
        <Avatar name="Ana Rivera" size={48} />
        <div>
          <p className="font-medium text-[var(--color-text-primary)]">Ana Rivera</p>
          <p className="text-[var(--text-small)] text-[var(--color-text-secondary)]">Contacto principal de Carmen Rivera</p>
          {user?.email && <p className="text-[var(--text-caption)] text-[var(--color-text-muted)] mt-1">Sesión: {user.email}</p>}
        </div>
      </Card>
      <Button variant="secondary" icon={<LogOut size={18} />} onClick={onLogout}>Cerrar sesión</Button>
    </div>
  );
}

export function FamilyNotificationsPage() {
  return (
    <div>
      <PageHeader title="Notificaciones" />
      <EmptyState icon={<MessageCircle size={28} />} title="No tienes notificaciones nuevas." />
    </div>
  );
}
