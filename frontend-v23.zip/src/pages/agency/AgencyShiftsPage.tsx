import { useState } from "react";
import { PageHeader, Card, StatusBadge, Button, Modal, Radio } from "@/components/ui";
import { useAllShifts, useResident, useAvailableWorkers, useAssignShift } from "@/mocks/DemoStoreContext";
import { useToast } from "@/components/ui";
import type { DemoShift } from "@/mocks/types";

function ShiftRow({ shift, onAssign }: { shift: DemoShift; onAssign: (shift: DemoShift) => void }) {
  const resident = useResident(shift.residentId);
  const worker = useAvailableWorkers().find((w) => w.id === shift.workerId);
  return (
    <Card className="flex items-center justify-between gap-3 flex-wrap">
      <div>
        <p className="font-medium text-[var(--color-text-primary)]">{resident?.name}</p>
        <p className="text-[var(--text-small)] text-[var(--color-text-secondary)]">
          {shift.start} – {shift.end} {worker ? `· ${worker.name}` : ""}
        </p>
      </div>
      <div className="flex items-center gap-2">
        <StatusBadge status={shift.status} />
        {shift.status === "unassigned" && (
          <Button size="md" onClick={() => onAssign(shift)}>Asignar cuidador</Button>
        )}
      </div>
    </Card>
  );
}

export function AgencyShiftsPage() {
  const shifts = useAllShifts();
  const availableWorkers = useAvailableWorkers();
  const assignShift = useAssignShift();
  const { show } = useToast();
  const [assigning, setAssigning] = useState<DemoShift | null>(null);
  const [selectedWorkerId, setSelectedWorkerId] = useState<string | null>(null);

  function confirmAssignment() {
    if (!assigning || !selectedWorkerId) return;
    const worker = availableWorkers.find((w) => w.id === selectedWorkerId);
    assignShift(assigning.id, selectedWorkerId);
    show(`Turno asignado a ${worker?.name}.`, "success");
    setAssigning(null);
    setSelectedWorkerId(null);
  }

  return (
    <div className="flex flex-col gap-[var(--spacing-md)]">
      <PageHeader title="Turnos" description="Cobertura de hoy y próximos días." />
      <div className="flex flex-col gap-2">
        {shifts.map((shift) => (
          <ShiftRow key={shift.id} shift={shift} onAssign={(s) => { setAssigning(s); setSelectedWorkerId(null); }} />
        ))}
      </div>

      <Modal
        open={!!assigning}
        onClose={() => setAssigning(null)}
        title="Asignar cuidador"
        footer={
          <>
            <Button variant="secondary" onClick={() => setAssigning(null)}>Cancelar</Button>
            <Button onClick={confirmAssignment} disabled={!selectedWorkerId}>Confirmar asignación</Button>
          </>
        }
      >
        <fieldset className="flex flex-col gap-3">
          <legend className="text-[var(--text-small)] text-[var(--color-text-secondary)] mb-1">
            Cuidadores disponibles
          </legend>
          {availableWorkers.map((w) => (
            <Radio
              key={w.id}
              name="worker"
              label={w.name}
              checked={selectedWorkerId === w.id}
              onChange={() => setSelectedWorkerId(w.id)}
            />
          ))}
        </fieldset>
      </Modal>
    </div>
  );
}
