import { Users, UserCheck, AlertTriangle, ShieldCheck } from "lucide-react";
import { PageHeader, StatCard, Card, SectionHeader, StatusBadge } from "@/components/ui";
import { useAllShifts, useResident, useWorkers, useIncidents, useRecentCareEvents, useShift } from "@/mocks/DemoStoreContext";

/**
 * Dashboard operacional leído en vivo del DemoStore compartido -- una
 * asignación hecha en /agency/shifts o un check-in hecho por el cuidador
 * se refleja aquí de inmediato, sin recargar nada.
 */
export function AgencyOverviewPage() {
  const shifts = useAllShifts();
  const workers = useWorkers();
  const incidents = useIncidents();

  const covered = shifts.filter((s) => s.status !== "unassigned").length;
  const unassigned = shifts.filter((s) => s.status === "unassigned").length;
  const activeNow = shifts.filter((s) => s.status === "in_progress").length;
  const expiringCredentials = workers.filter((w) => w.credentialStatus === "expiring").length;

  return (
    <div className="flex flex-col gap-[var(--spacing-lg)]">
      <PageHeader title="Overview" description="Residencial Los Almendros · hoy" />

      <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
        <StatCard label="Turnos cubiertos" value={covered} tone="success" icon={<UserCheck size={18} />} />
        <StatCard
          label="Turnos sin cubrir"
          value={unassigned}
          tone={unassigned > 0 ? "warning" : "neutral"}
          hint={unassigned > 0 ? "Requiere asignación" : undefined}
          icon={<Users size={18} />}
        />
        <StatCard label="Incidentes abiertos" value={incidents.length} tone={incidents.length > 0 ? "danger" : "neutral"} icon={<AlertTriangle size={18} />} />
        <StatCard
          label="Credenciales por vencer"
          value={expiringCredentials}
          tone={expiringCredentials > 0 ? "warning" : "neutral"}
          hint="Próximos 30 días"
          icon={<ShieldCheck size={18} />}
        />
      </div>

      {activeNow > 0 && (
        <Card className="border-[var(--color-success-700)]/30 bg-[var(--color-success-100)]/40">
          <p className="text-[var(--text-small)] font-medium text-[var(--color-success-700)]">
            {activeNow} turno{activeNow > 1 ? "s" : ""} en curso ahora mismo
          </p>
        </Card>
      )}

      <div>
        <SectionHeader title="Turnos de hoy" />
        <div className="flex flex-col gap-2">
          {shifts.map((shift) => <ShiftSummaryRow key={shift.id} residentId={shift.residentId} status={shift.status} />)}
        </div>
      </div>

      <div>
        <SectionHeader title="Actividad reciente" />
        <RecentActivityList />
      </div>
    </div>
  );
}

const eventLabel: Record<string, string> = {
  check_in: "Check-in",
  check_out: "Check-out",
  meal: "Comida registrada",
  water: "Agua registrada",
  mobility: "Movilidad registrada",
  mood: "Estado de ánimo registrado",
  observation: "Observación registrada",
  incident: "Incidente reportado",
};

function RecentActivityList() {
  const events = useRecentCareEvents(6);
  if (events.length === 0) {
    return <p className="text-[var(--text-small)] text-[var(--color-text-muted)]">No hay actividad registrada todavía.</p>;
  }
  return (
    <div className="flex flex-col gap-2">
      {events.map((e) => <RecentActivityRow key={e.id} eventId={e.id} type={e.type} shiftId={e.shiftId} createdAt={e.createdAt} />)}
    </div>
  );
}

function RecentActivityRow({ type, shiftId, createdAt }: { eventId: string; type: string; shiftId: string; createdAt: string }) {
  const shift = useShift(shiftId);
  const resident = useResident(shift?.residentId);
  return (
    <Card className="flex items-center justify-between py-2.5">
      <p className="text-[var(--text-body)] text-[var(--color-text-primary)]">
        {eventLabel[type] ?? type} <span className="text-[var(--color-text-secondary)]">· {resident?.name}</span>
      </p>
      <span className="text-[var(--text-caption)] text-[var(--color-text-muted)]">
        {new Date(createdAt).toLocaleTimeString("es-PR", { hour: "numeric", minute: "2-digit" })}
      </span>
    </Card>
  );
}

function ShiftSummaryRow({ residentId, status }: { residentId: string; status: ReturnType<typeof useAllShifts>[number]["status"] }) {
  const resident = useResident(residentId);
  return (
    <Card className="flex items-center justify-between">
      <p className="font-medium text-[var(--color-text-primary)]">{resident?.name}</p>
      <StatusBadge status={status} />
    </Card>
  );
}
