import { useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import {
  Utensils, GlassWater, Footprints, Smile, Eye, AlertTriangle, LogIn, LogOut, MessageCircle,
} from "lucide-react";
import {
  Button, Card, PageHeader, BottomSheet, Textarea, Select, StatusBadge, Timeline, useToast,
} from "@/components/ui";
import {
  useShift, useResident, useCareEventsForShift, useCheckIn, useCheckOut, useAddCareEvent,
  useConversationsForResident,
} from "@/mocks/DemoStoreContext";
import type { CareEventType, DemoCareEvent } from "@/mocks/types";

const ACTIONS: { id: CareEventType; label: string; icon: React.ReactNode; tone?: "danger" }[] = [
  { id: "meal", label: "Comida", icon: <Utensils size={22} /> },
  { id: "water", label: "Agua", icon: <GlassWater size={22} /> },
  { id: "mobility", label: "Movilidad", icon: <Footprints size={22} /> },
  { id: "mood", label: "Estado de ánimo", icon: <Smile size={22} /> },
  { id: "observation", label: "Observación", icon: <Eye size={22} /> },
  { id: "incident", label: "Incidente", icon: <AlertTriangle size={22} />, tone: "danger" },
];

function timelineToneFor(type: CareEventType): "neutral" | "warning" | "danger" | undefined {
  if (type === "incident") return "danger";
  if (type === "observation") return "warning";
  return undefined;
}

function summarize(e: DemoCareEvent): string {
  switch (e.type) {
    case "check_in": return "Check-in registrado";
    case "check_out": return "Check-out registrado";
    case "meal": return `Comida${e.mealSubtype ? ` · ${e.mealSubtype}` : ""}${e.mealPercent != null ? ` · ${e.mealPercent}%` : ""}`;
    case "water": return `Agua${e.note ? ` · ${e.note}` : ""}`;
    case "mobility": return `Movilidad${e.note ? ` · ${e.note}` : ""}`;
    case "mood": return `Estado de ánimo${e.mood ? ` · ${e.mood}` : ""}`;
    case "observation": return `Observación · ${e.note ?? "sin nota"}`;
    case "incident": return `Incidente · ${e.incidentType ?? "sin tipo"} · severidad ${e.incidentSeverity ?? "?"}`;
  }
}

export function CaregiverShiftDetailPage() {
  const { shiftId } = useParams();
  const navigate = useNavigate();
  const shift = useShift(shiftId);
  const resident = useResident(shift?.residentId);
  const events = useCareEventsForShift(shiftId ?? "");
  const checkIn = useCheckIn();
  const checkOut = useCheckOut();
  const addCareEvent = useAddCareEvent();
  const conversations = useConversationsForResident(shift?.residentId ?? "");
  const caregiverConvo = conversations.find((c) => c.kind === "caregiver");
  const { show } = useToast();

  const [openAction, setOpenAction] = useState<CareEventType | null>(null);
  const [mealSubtype, setMealSubtype] = useState<"breakfast" | "lunch" | "dinner">("breakfast");
  const [mealPercent, setMealPercent] = useState(75);
  const [mood, setMood] = useState<"calm" | "happy" | "agitated" | "sad">("calm");
  const [note, setNote] = useState("");
  const [incidentType, setIncidentType] = useState("Caída");
  const [incidentSeverity, setIncidentSeverity] = useState<"low" | "medium" | "high" | "critical">("medium");

  if (!shift || !resident) return null;
  const active = ACTIONS.find((a) => a.id === openAction);

  function resetForm() {
    setNote("");
    setMealPercent(75);
    setOpenAction(null);
  }

  function saveEvent() {
    if (!openAction || !shift) return;
    const base = { shiftId: shift.id, type: openAction };
    if (openAction === "meal") addCareEvent({ ...base, mealSubtype, mealPercent, note: note || undefined });
    else if (openAction === "mood") addCareEvent({ ...base, mood, note: note || undefined });
    else if (openAction === "incident") addCareEvent({ ...base, incidentType, incidentSeverity, note });
    else addCareEvent({ ...base, note: note || undefined });
    show(`${active?.label} registrado en el timeline.`, openAction === "incident" ? "danger" : "success");
    resetForm();
  }

  const timelineEntries = events.map((e) => ({
    id: e.id,
    time: new Date(e.createdAt).toLocaleTimeString("es-PR", { hour: "numeric", minute: "2-digit" }),
    title: summarize(e),
    tone: timelineToneFor(e.type),
  }));

  return (
    <div className="flex flex-col gap-[var(--spacing-md)]">
      <PageHeader
        title={resident.name}
        breadcrumbs={[{ label: "Turnos", href: "/caregiver/shifts" }, { label: "Detalle" }]}
        actions={<StatusBadge status={shift.status} />}
      />

      <div className="grid grid-cols-2 gap-3">
        <Button
          variant="secondary" size="lg" icon={<LogIn size={18} />}
          disabled={shift.status !== "assigned"}
          onClick={() => { checkIn(shift.id); show("Check-in registrado.", "success"); }}
        >
          Check-in
        </Button>
        <Button
          variant="secondary" size="lg" icon={<LogOut size={18} />}
          disabled={shift.status !== "in_progress"}
          onClick={() => { checkOut(shift.id); show("Check-out registrado. Turno completado.", "success"); navigate("/caregiver/shifts"); }}
        >
          Check-out
        </Button>
      </div>

      <div>
        <p className="text-[var(--text-small)] font-medium text-[var(--color-text-secondary)] mb-3">Registrar cuidado</p>
        <div className="grid grid-cols-3 gap-2.5">
          {ACTIONS.map((action) => (
            <button
              key={action.id}
              disabled={shift.status !== "in_progress"}
              onClick={() => setOpenAction(action.id)}
              className={`flex flex-col items-center justify-center gap-1.5 rounded-[var(--radius-md)] border border-[var(--color-border)]
                bg-[var(--color-surface)] py-3.5 min-h-[76px] text-[var(--text-caption)] font-medium
                transition-transform active:scale-95 disabled:opacity-40
                ${action.tone === "danger" ? "text-[var(--color-danger-700)]" : "text-[var(--color-text-primary)]"}`}
            >
              {action.icon}
              {action.label}
            </button>
          ))}
        </div>
        {shift.status !== "in_progress" && (
          <p className="text-[var(--text-caption)] text-[var(--color-text-muted)] mt-2">
            Haz check-in para poder registrar cuidados.
          </p>
        )}
      </div>

      {caregiverConvo && (
        <Button
          variant="secondary" icon={<MessageCircle size={18} />}
          onClick={() => navigate("/caregiver/messages")}
        >
          Enviar mensaje sobre {resident.name.split(" ")[0]}
        </Button>
      )}

      <Card>
        <p className="text-[var(--text-small)] font-medium text-[var(--color-text-secondary)] mb-3">Línea de tiempo del turno</p>
        {timelineEntries.length > 0 ? (
          <Timeline entries={timelineEntries} />
        ) : (
          <p className="text-[var(--text-small)] text-[var(--color-text-muted)]">Sin registros todavía.</p>
        )}
      </Card>

      <BottomSheet
        open={!!active}
        onClose={resetForm}
        title={active?.label ?? ""}
        footer={
          <>
            <Button variant="secondary" fullWidth onClick={resetForm}>Cancelar</Button>
            <Button fullWidth onClick={saveEvent}>Guardar</Button>
          </>
        }
      >
        {openAction === "meal" && (
          <div className="flex flex-col gap-3">
            <Select label="Comida" value={mealSubtype} onChange={(e) => setMealSubtype(e.target.value as typeof mealSubtype)}>
              <option value="breakfast">Desayuno</option>
              <option value="lunch">Almuerzo</option>
              <option value="dinner">Cena</option>
            </Select>
            <label className="text-[var(--text-small)] font-medium text-[var(--color-text-primary)]">
              Consumido: {mealPercent}%
              <input
                type="range" min={0} max={100} step={25} value={mealPercent}
                onChange={(e) => setMealPercent(Number(e.target.value))}
                className="w-full mt-2 accent-[var(--color-navy-800)]"
              />
            </label>
          </div>
        )}
        {openAction === "mood" && (
          <Select label="Estado de ánimo" value={mood} onChange={(e) => setMood(e.target.value as typeof mood)}>
            <option value="calm">Tranquila</option>
            <option value="happy">Contenta</option>
            <option value="agitated">Inquieta</option>
            <option value="sad">Decaída</option>
          </Select>
        )}
        {openAction === "incident" && (
          <div className="flex flex-col gap-3">
            <Select label="Tipo de incidente" value={incidentType} onChange={(e) => setIncidentType(e.target.value)}>
              <option>Caída</option>
              <option>Reacción a medicamento</option>
              <option>Confusión repentina</option>
              <option>Otro</option>
            </Select>
            <Select label="Severidad" value={incidentSeverity} onChange={(e) => setIncidentSeverity(e.target.value as typeof incidentSeverity)}>
              <option value="low">Baja</option>
              <option value="medium">Media</option>
              <option value="high">Alta</option>
              <option value="critical">Crítica</option>
            </Select>
          </div>
        )}
        {(openAction === "water" || openAction === "mobility" || openAction === "observation" || openAction === "incident") && (
          <div className="mt-3">
            <Textarea
              label={openAction === "incident" ? "Descripción del incidente" : "Nota"}
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="Detalles..."
            />
          </div>
        )}
      </BottomSheet>
    </div>
  );
}
