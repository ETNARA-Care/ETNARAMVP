import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate, useParams } from "react-router-dom";
import { LogIn, LogOut, MessageCircle } from "lucide-react";
import { useAuth } from "@/auth/AuthProvider";
import { getToken } from "@/auth/token";
import type { ApiError } from "@/api/client";
import {
  checkIn, checkOut, getShift, getVisitVerification, listCareRecipients, recipientName,
  type CareRecipient, type Shift, type ShiftStatus, type VisitVerification,
} from "@/api/shifts";
import { Button, Card, ErrorState, PageHeader, Skeleton, StatusBadge, Timeline, useToast } from "@/components/ui";

function actionError(error: unknown): string {
  const apiError = error as ApiError;
  if (apiError.status === 0) return "No hay conexión con el servidor.";
  if (apiError.code === "WORKER_NOT_ELIGIBLE") return "Tu elegibilidad necesita revisión antes de comenzar.";
  if (apiError.code === "ALREADY_CHECKED_IN") return "Este turno ya fue iniciado.";
  if (apiError.code === "NO_ACTIVE_CHECK_IN") return "No encontramos una llegada activa para finalizar.";
  if (apiError.code === "NOT_FOUND") return "Este turno ya no está asignado a tu cuenta.";
  return "No pudimos registrar la acción. Intenta nuevamente.";
}

function effectiveStatus(shift: Shift, verification: VisitVerification): ShiftStatus {
  if (verification.status === "in_progress") return "in_progress";
  if (verification.status === "completed") return "completed";
  return shift.status;
}

export function CaregiverShiftDetailPage() {
  const { shiftId } = useParams();
  const navigate = useNavigate();
  const { activeOrganization } = useAuth();
  const { show } = useToast();
  const [shift, setShift] = useState<Shift | null>(null);
  const [recipient, setRecipient] = useState<CareRecipient | undefined>();
  const [verification, setVerification] = useState<VisitVerification | null>(null);
  const [error, setError] = useState(false);
  const [saving, setSaving] = useState(false);
  const organizationId = activeOrganization?.id;

  const load = useCallback(async () => {
    const token = getToken();
    if (!organizationId || !shiftId || !token) return;
    setError(false);
    try {
      const [shiftRow, summary, recipientRows] = await Promise.all([
        getShift(organizationId, shiftId, token),
        getVisitVerification(organizationId, shiftId, token),
        listCareRecipients(organizationId, token),
      ]);
      setShift(shiftRow);
      setVerification(summary);
      setRecipient(recipientRows.find((item) => item.id === shiftRow.care_recipient_id));
    } catch {
      setError(true);
    }
  }, [organizationId, shiftId]);

  useEffect(() => { void load(); }, [load]);

  const timelineEntries = useMemo(() => (verification?.events ?? []).map((event) => ({
    id: event.id,
    time: new Date(event.occurredAt).toLocaleTimeString("es-PR", { hour: "numeric", minute: "2-digit" }),
    title: event.eventType === "check_in" ? "Llegada registrada · turno iniciado" : "Salida registrada · turno finalizado",
  })), [verification]);

  async function startShift() {
    const token = getToken();
    if (!organizationId || !shiftId || !token) return;
    setSaving(true);
    try {
      await checkIn(organizationId, shiftId, token);
      show("Llegada registrada. Turno iniciado.", "success");
      await load();
    } catch (requestError) { show(actionError(requestError), "danger"); }
    finally { setSaving(false); }
  }

  async function finishShift() {
    const token = getToken();
    if (!organizationId || !shiftId || !token) return;
    setSaving(true);
    try {
      await checkOut(organizationId, shiftId, token);
      show("Salida registrada. Turno finalizado.", "success");
      navigate("/caregiver/shifts");
    } catch (requestError) { show(actionError(requestError), "danger"); }
    finally { setSaving(false); }
  }

  if (error) return <ErrorState kind="not_found" onRetry={() => void load()} />;
  if (!shift || !verification) return <div className="flex flex-col gap-3"><Skeleton className="h-20" /><Skeleton className="h-32" /></div>;

  const status = effectiveStatus(shift, verification);
  const canStart = verification.status === "not_started" && status !== "cancelled" && status !== "completed";
  const canFinish = verification.status === "in_progress";

  return (
    <div className="flex flex-col gap-[var(--spacing-md)]">
      <PageHeader title={recipientName(recipient)} breadcrumbs={[{ label: "Turnos", href: "/caregiver/shifts" }, { label: "Detalle" }]} actions={<StatusBadge status={status} />} />

      <Card>
        <p className="font-medium text-[var(--color-text-primary)]">
          {new Date(shift.scheduled_start).toLocaleDateString("es-PR", { weekday: "long", day: "numeric", month: "long" })}
        </p>
        <p className="text-[var(--text-small)] text-[var(--color-text-secondary)]">
          {new Date(shift.scheduled_start).toLocaleTimeString("es-PR", { hour: "numeric", minute: "2-digit" })} – {new Date(shift.scheduled_end).toLocaleTimeString("es-PR", { hour: "numeric", minute: "2-digit" })}
        </p>
      </Card>

      <div className="grid grid-cols-2 gap-3">
        <Button variant="secondary" size="lg" icon={<LogIn size={18} />} disabled={!canStart || saving} onClick={() => void startShift()}>
          Comenzar turno
        </Button>
        <Button variant="secondary" size="lg" icon={<LogOut size={18} />} disabled={!canFinish || saving} onClick={() => void finishShift()}>
          Finalizar turno
        </Button>
      </div>

      <Button variant="secondary" icon={<MessageCircle size={18} />} onClick={() => navigate("/caregiver/messages")}>
        Enviar mensaje sobre {recipientName(recipient).split(" ")[0]}
      </Button>

      <Card>
        <p className="text-[var(--text-small)] font-medium text-[var(--color-text-secondary)] mb-3">Actividad del turno</p>
        {timelineEntries.length > 0 ? <Timeline entries={timelineEntries} /> : <p className="text-[var(--text-small)] text-[var(--color-text-muted)]">Aún no se ha registrado la llegada.</p>}
      </Card>

      <Card className="bg-[var(--color-ivory-100)]">
        <p className="text-[var(--text-small)] text-[var(--color-text-secondary)]">Los registros de comida, agua, movilidad y observaciones se conectarán en el próximo módulo. Esta pantalla ya no guarda datos simulados.</p>
      </Card>
    </div>
  );
}
