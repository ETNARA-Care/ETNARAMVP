import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { PageHeader, Card, Avatar, Button } from "@/components/ui";
import { LogOut } from "lucide-react";
import { ConversationList, ConversationThread } from "@/features/messaging/ConversationUI";
import { useConversationsForParticipant } from "@/mocks/DemoStoreContext";
import { DEMO_IDENTITIES } from "@/mocks/seed";
import { useAuth } from "@/auth/AuthProvider";

export function CaregiverMessagesPage() {
  const conversations = useConversationsForParticipant(DEMO_IDENTITIES.caregiverId);
  const [openId, setOpenId] = useState<string | null>(null);

  if (openId) {
    return (
      <ConversationThread
        conversationId={openId}
        currentParticipantId={DEMO_IDENTITIES.caregiverId}
        currentParticipantName="María Rivera"
        onBack={() => setOpenId(null)}
      />
    );
  }

  return (
    <div>
      <PageHeader title="Mensajes" />
      <ConversationList
        conversations={conversations}
        currentParticipantId={DEMO_IDENTITIES.caregiverId}
        onOpen={setOpenId}
        emptyLabel="No tienes mensajes nuevos."
      />
    </div>
  );
}

export function CaregiverProfilePage() {
  const { user, logout } = useAuth();
  const navigate = useNavigate();

  async function onLogout() {
    await logout();
    navigate("/login", { replace: true });
  }

  return (
    <div className="flex flex-col gap-[var(--spacing-md)]">
      <PageHeader title="Perfil" />
      <Card className="flex items-center gap-3">
        <Avatar name="María Rivera" size={48} />
        <div>
          <p className="font-medium text-[var(--color-text-primary)]">María Rivera</p>
          <p className="text-[var(--text-small)] text-[var(--color-text-secondary)]">Cuidadora certificada</p>
          {user?.email && <p className="text-[var(--text-caption)] text-[var(--color-text-muted)] mt-1">Sesión: {user.email}</p>}
        </div>
      </Card>
      <Button variant="secondary" icon={<LogOut size={18} />} onClick={onLogout}>Cerrar sesión</Button>
    </div>
  );
}
