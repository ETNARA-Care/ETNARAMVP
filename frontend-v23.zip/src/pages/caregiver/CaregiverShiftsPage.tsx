import { Link } from "react-router-dom";
import { PageHeader, Card, StatusBadge } from "@/components/ui";
import { useShiftsForWorker, useResident } from "@/mocks/DemoStoreContext";
import { DEMO_IDENTITIES } from "@/mocks/seed";
import type { DemoShift } from "@/mocks/types";

function ShiftCard({ shift }: { shift: DemoShift }) {
  const resident = useResident(shift.residentId);
  return (
    <Link to={`/caregiver/shifts/${shift.id}`}>
      <Card className="flex items-center justify-between gap-3">
        <div>
          <p className="font-medium text-[var(--color-text-primary)]">{resident?.name}</p>
          <p className="text-[var(--text-small)] text-[var(--color-text-secondary)]">
            {shift.start} – {shift.end}
          </p>
        </div>
        <StatusBadge status={shift.status} />
      </Card>
    </Link>
  );
}

export function CaregiverShiftsPage() {
  const shifts = useShiftsForWorker(DEMO_IDENTITIES.caregiverId);
  const upcoming = shifts.filter((s) => s.status !== "completed");
  const completed = shifts.filter((s) => s.status === "completed");

  return (
    <div className="flex flex-col gap-[var(--spacing-lg)]">
      <PageHeader title="Tus turnos" description="Próximos y recientes." />
      <div>
        <p className="text-[var(--text-small)] font-medium text-[var(--color-text-secondary)] mb-2">Próximos</p>
        <div className="flex flex-col gap-3">
          {upcoming.length > 0 ? (
            upcoming.map((s) => <ShiftCard key={s.id} shift={s} />)
          ) : (
            <p className="text-[var(--text-small)] text-[var(--color-text-muted)]">No tienes turnos programados hoy.</p>
          )}
        </div>
      </div>
      {completed.length > 0 && (
        <div>
          <p className="text-[var(--text-small)] font-medium text-[var(--color-text-secondary)] mb-2">Completados</p>
          <div className="flex flex-col gap-3">
            {completed.map((s) => <ShiftCard key={s.id} shift={s} />)}
          </div>
        </div>
      )}
    </div>
  );
}
