import { useState } from "react";
import { ArrowLeft, Send } from "lucide-react";
import { Card, Avatar, IconButton, Badge } from "@/components/ui";
import { useConversation, useMessagesForConversation, useSendMessage } from "@/mocks/DemoStoreContext";
import type { DemoConversation } from "@/mocks/types";

interface ConversationListProps {
  conversations: DemoConversation[];
  currentParticipantId: string;
  onOpen: (conversationId: string) => void;
  emptyLabel: string;
}

/** Lista de conversaciones -- usada tal cual en Familiar, Cuidador y Agencia. */
export function ConversationList({ conversations, currentParticipantId, onOpen, emptyLabel }: ConversationListProps) {
  if (conversations.length === 0) {
    return <p className="text-[var(--text-small)] text-[var(--color-text-secondary)] py-6 text-center">{emptyLabel}</p>;
  }
  return (
    <div className="flex flex-col gap-2">
      {conversations.map((c) => (
        <ConversationPreview key={c.id} conversation={c} currentParticipantId={currentParticipantId} onOpen={onOpen} />
      ))}
    </div>
  );
}

function ConversationPreview({
  conversation, currentParticipantId, onOpen,
}: { conversation: DemoConversation; currentParticipantId: string; onOpen: (id: string) => void }) {
  const messages = useMessagesForConversation(conversation.id);
  const last = messages[messages.length - 1];
  const unread = !!last && last.senderId !== currentParticipantId;
  return (
    <button onClick={() => onOpen(conversation.id)} className="text-left">
      <Card className="flex items-center gap-3">
        <Avatar name={conversation.title} size={44} />
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className="font-medium text-[var(--color-text-primary)] truncate">{conversation.title}</p>
            {unread && <Badge tone="accent">Nuevo</Badge>}
          </div>
          <p className="text-[var(--text-small)] text-[var(--color-text-secondary)] truncate">
            {last ? last.text : "Sin mensajes todavía"}
          </p>
        </div>
      </Card>
    </button>
  );
}

interface ConversationThreadProps {
  conversationId: string;
  currentParticipantId: string;
  currentParticipantName: string;
  onBack: () => void;
}

/** Vista de hilo -- enviar aquí escribe en el DemoStore compartido, visible de inmediato del otro lado. */
export function ConversationThread({ conversationId, currentParticipantId, currentParticipantName, onBack }: ConversationThreadProps) {
  const conversation = useConversation(conversationId);
  const messages = useMessagesForConversation(conversationId);
  const sendMessage = useSendMessage();
  const [draft, setDraft] = useState("");

  function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!draft.trim()) return;
    sendMessage(conversationId, currentParticipantId, currentParticipantName, draft.trim());
    setDraft("");
  }

  if (!conversation) return null;

  return (
    <div className="flex flex-col h-[calc(100dvh-220px)]">
      <div className="flex items-center gap-2 pb-3 border-b border-[var(--color-border)]">
        <IconButton icon={<ArrowLeft size={18} />} label="Volver" onClick={onBack} />
        <p className="font-display text-[var(--text-h3)]">{conversation.title}</p>
      </div>
      <div className="flex-1 overflow-y-auto py-3 flex flex-col gap-2">
        {messages.length === 0 && (
          <p className="text-[var(--text-small)] text-[var(--color-text-muted)] text-center py-6">
            Aún no hay mensajes en esta conversación.
          </p>
        )}
        {messages.map((m) => {
          const mine = m.senderId === currentParticipantId;
          return (
            <div key={m.id} className={`max-w-[80%] ${mine ? "self-end items-end" : "self-start"} flex flex-col gap-0.5`}>
              <div
                className={`rounded-[var(--radius-md)] px-3.5 py-2.5 text-[var(--text-body)]
                  ${mine ? "bg-[var(--color-navy-800)] text-white" : "bg-[var(--color-ivory-100)] text-[var(--color-text-primary)]"}`}
              >
                {m.text}
              </div>
              <span className="text-[var(--text-caption)] text-[var(--color-text-muted)] px-1">
                {mine ? "Tú" : m.senderName}
              </span>
            </div>
          );
        })}
      </div>
      <form onSubmit={submit} className="flex items-center gap-2 pt-2 border-t border-[var(--color-border)]">
        <input
          value={draft}
          onChange={(e) => setDraft(e.target.value)}
          placeholder="Escribe un mensaje..."
          aria-label="Escribe un mensaje"
          className="flex-1 h-11 rounded-[var(--radius-pill)] border border-[var(--color-border)] px-4 text-[var(--text-body)]"
        />
        <IconButton icon={<Send size={18} />} label="Enviar" type="submit" variant="primary" />
      </form>
    </div>
  );
}
