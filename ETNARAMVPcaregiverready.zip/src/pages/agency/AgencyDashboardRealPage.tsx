import { useEffect, useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { useAuth } from "../../auth/AuthContext";
import {
  listOrgCareRecipients,
  getShiftCoverage,
  listOrgWorkers,
  listOrgShifts,
  type OrgCareRecipient,
  type CoverageSummary,
  type OrgShift,
  type OrgWorkerMembership,
} from "../../api/agency";
import { listMyNotifications } from "../../api/notifications";
import { LoadingState, ErrorState } from "../../components/UiStates";
import { Card, Avatar } from "../../components/Primitives";
import { Badge } from "../../components/Badge";
import { ChevronRightIcon, AlertIcon } from "../../components/icons";

// ── helpers ──────────────────────────────────────────────────────────────────

function greeting() {
  const h = new Date().getHours();
  if (h < 12) return "Buenos días";
  if (h < 19) return "Buenas tardes";
  return "Buenas noches";
}

function orgTypeLabel(type: string) {
  if (type === "RESIDENTIAL_CARE_HOME") return "Hogar de cuidado residencial";
  if (type === "HOME_CARE_AGENCY") return "Agencia de cuidado a domicilio";
  return type;
}

function formatTime(iso: string) {
  return new Date(iso).toLocaleTimeString("es", { hour: "2-digit", minute: "2-digit", hour12: false });
}

function formatDate(iso: string) {
  return new Date(iso).toLocaleDateString("es", { weekday: "short", day: "numeric", month: "short" });
}

function shiftStatusBadge(status: string) {
  if (status === "scheduled") return <Badge tone="neutral" size="sm">Programado</Badge>;
  if (status === "active" || status === "in_progress") return <Badge tone="active" size="sm">En curso</Badge>;
  if (status === "completed") return <Badge tone="verified" size="sm">Completado</Badge>;
  if (status === "unassigned" || status === "open") return <Badge tone="warning" size="sm">Sin cubrir</Badge>;
  if (status === "cancelled") return <Badge tone="critical" size="sm">Cancelado</Badge>;
  return <Badge tone="neutral" size="sm">{status}</Badge>;
}

function recipientStatusBadge(r: OrgCareRecipient) {
  if (r.status === "active") return <Badge tone="active" size="sm">Cuidado activo</Badge>;
  if (r.status === "inactive") return <Badge tone="neutral" size="sm">Inactivo</Badge>;
  return <Badge tone="neutral" size="sm">{r.status}</Badge>;
}

function recipientInitials(r: OrgCareRecipient) {
  const first = (r.preferred_name ?? r.first_name)[0] ?? "";
  const last = r.last_name[0] ?? "";
  return (first + last).toUpperCase();
}

const AVATAR_COLORS = ["#e7cf9f", "#bcd4c7", "#e3c2b8", "#c4d0e3", "#d4c4e3"];

// ── sub-components ────────────────────────────────────────────────────────────

function StatCard({
  label,
  value,
  tone,
}: {
  label: string;
  value: string | number;
  tone?: "warning" | "critical" | "verified";
}) {
  const colors: Record<string, string> = {
    warning: "var(--color-warning)",
    critical: "var(--color-critical)",
    verified: "var(--color-verified)",
  };
  const bgs: Record<string, string> = {
    warning: "var(--color-warning-bg)",
    critical: "var(--color-critical-bg)",
    verified: "var(--color-verified-bg)",
  };
  return (
    <div
      style={{
        background: tone ? bgs[tone] : "var(--color-surface)",
        border: `1px solid ${tone ? colors[tone] + "44" : "var(--color-border)"}`,
        borderRadius: "var(--radius-md)",
        boxShadow: "var(--shadow-card)",
        padding: "var(--space-4) var(--space-5)",
        flex: "1 1 148px",
        minWidth: 120,
      }}
    >
      <p
        style={{
          margin: 0,
          fontSize: 30,
          fontFamily: "var(--font-display)",
          fontWeight: 600,
          color: tone ? colors[tone] : "var(--color-ink)",
          lineHeight: 1.1,
        }}
      >
        {value}
      </p>
      <p
        style={{
          margin: "4px 0 0",
          fontSize: "var(--fs-caption)",
          color: tone ? colors[tone] : "var(--color-ink-soft)",
        }}
      >
        {label}
      </p>
    </div>
  );
}

function SectionHeader({ title, to, toLabel }: { title: string; to?: string; toLabel?: string }) {
  return (
    <div
      style={{
        display: "flex",
        alignItems: "baseline",
        justifyContent: "space-between",
        marginBottom: "var(--space-3)",
        marginTop: "var(--space-6)",
      }}
    >
      <h2 style={{ fontSize: "var(--fs-title)", margin: 0 }}>{title}</h2>
      {to && (
        <Link
          to={to}
          style={{
            fontSize: "var(--fs-caption)",
            color: "var(--color-ink-soft)",
            textDecoration: "none",
            display: "flex",
            alignItems: "center",
            gap: 4,
          }}
        >
          {toLabel ?? "Ver todo"} <ChevronRightIcon size={14} />
        </Link>
      )}
    </div>
  );
}

// ── main page ─────────────────────────────────────────────────────────────────

export function AgencyDashboardRealPage() {
  const { activeOrganization, user } = useAuth();
  const navigate = useNavigate();

  const [recipients, setRecipients] = useState<OrgCareRecipient[] | null>(null);
  const [coverage, setCoverage] = useState<CoverageSummary | null>(null);
  const [workers, setWorkers] = useState<OrgWorkerMembership[] | null>(null);
  const [shifts, setShifts] = useState<OrgShift[] | null>(null);
  const [unreadCount, setUnreadCount] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const organizationId = activeOrganization?.id;

  useEffect(() => {
    if (!organizationId) return;
    let cancelled = false;
    setLoading(true);
    setError(null);

    const today = new Date(Date.now() - new Date().getTimezoneOffset() * 60_000)
      .toISOString()
      .slice(0, 10);

    Promise.all([
      listOrgCareRecipients(organizationId),
      getShiftCoverage(organizationId),
      listOrgWorkers(organizationId),
      listOrgShifts(organizationId, { dateFrom: today }),
      listMyNotifications(),
    ])
      .then(([recipientsRes, coverageRes, workersRes, shiftsRes, notifsRes]) => {
        if (cancelled) return;
        setRecipients(recipientsRes);
        setCoverage(coverageRes);
        setWorkers(workersRes);
        setShifts(shiftsRes);
        setUnreadCount(notifsRes.items.filter((n) => !n.readAt).length);
      })
      .catch(() => !cancelled && setError("No pudimos cargar la información del panel."))
      .finally(() => !cancelled && setLoading(false));

    return () => {
      cancelled = true;
    };
  }, [organizationId]);

  if (!organizationId) return <LoadingState />;
  if (loading) return <LoadingState label="Cargando panel..." />;
  if (error) return <ErrorState description={error} />;

  const activeRecipients = recipients?.filter((r) => r.status === "active") ?? [];
  const activeWorkers = workers?.filter((w) => w.status === "active") ?? [];
  const uncoveredShifts = shifts?.filter((s) => s.status === "unassigned" || s.status === "open") ?? [];
  const upcomingShifts = (shifts ?? []).slice(0, 3);

  return (
    <div style={{ padding: "var(--space-6) var(--space-6) var(--space-8)", maxWidth: 960, margin: "0 auto" }}>
      {/* ── ENCABEZADO ──────────────────────────────────────────────────── */}
      <div
        style={{
          background: "var(--color-surface)",
          border: "1px solid var(--color-border)",
          borderRadius: "var(--radius-lg)",
          boxShadow: "var(--shadow-lift)",
          padding: "var(--space-6)",
          marginBottom: "var(--space-6)",
          display: "flex",
          justifyContent: "space-between",
          alignItems: "flex-start",
          flexWrap: "wrap",
          gap: 16,
        }}
      >
        <div>
          <p
            style={{
              margin: "0 0 2px",
              fontSize: "var(--fs-caption)",
              color: "var(--color-ink-soft)",
              textTransform: "uppercase",
              letterSpacing: "0.08em",
            }}
          >
            {greeting()}
          </p>
          <h1 style={{ fontSize: "var(--fs-display-lg)", margin: "0 0 4px" }}>
            {activeOrganization.name}
          </h1>
          <p style={{ margin: 0, fontSize: "var(--fs-caption)", color: "var(--color-ink-soft)" }}>
            {user?.email ? `${user.email} · ` : ""}
            {orgTypeLabel(activeOrganization.type)}
          </p>
        </div>
        <div style={{ display: "flex", gap: 8 }}>
          <Link
            to="/messages"
            style={{
              padding: "10px 18px",
              borderRadius: "var(--radius-md)",
              background: "var(--color-ink-tint)",
              color: "var(--color-ink)",
              fontWeight: 600,
              textDecoration: "none",
              fontSize: "var(--fs-caption)",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            Mensajes
          </Link>
          <Link
            to="/notifications"
            style={{
              padding: "10px 18px",
              borderRadius: "var(--radius-md)",
              background: unreadCount ? "var(--color-warning-bg)" : "var(--color-ink-tint)",
              color: unreadCount ? "var(--color-warning)" : "var(--color-ink)",
              fontWeight: 600,
              textDecoration: "none",
              fontSize: "var(--fs-caption)",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            Notificaciones {unreadCount ? `(${unreadCount})` : ""}
          </Link>
        </div>
      </div>

      {/* ── MÉTRICAS ─────────────────────────────────────────────────────── */}
      <div style={{ display: "flex", gap: "var(--space-3)", flexWrap: "wrap" }}>
        <StatCard
          label={activeOrganization.type === "RESIDENTIAL_CARE_HOME" ? "Residentes activos" : "Personas activas"}
          value={activeRecipients.length}
        />
        <StatCard label="Miembros del equipo" value={activeWorkers.length} />
        <StatCard
          label="Turnos cubiertos"
          value={coverage ? `${coverage.covered}/${coverage.total}` : "—"}
        />
        <StatCard
          label="Turnos sin cubrir"
          value={coverage?.uncovered ?? "—"}
          tone={coverage && coverage.uncovered > 0 ? "warning" : undefined}
        />
        <StatCard
          label="Notificaciones sin leer"
          value={unreadCount ?? "—"}
          tone={unreadCount && unreadCount > 0 ? "warning" : undefined}
        />
      </div>

      {/* ── AHORA ─────────────────────────────────────────────────────────── */}
      <SectionHeader title="Ahora" to="/agency/personas" toLabel="Ver personas" />

      {activeRecipients.length === 0 && (
        <div
          style={{
            background: "var(--color-surface-muted)",
            borderRadius: "var(--radius-md)",
            padding: "var(--space-6)",
            textAlign: "center",
            color: "var(--color-ink-soft)",
            fontSize: "var(--fs-body)",
          }}
        >
          Todavía no hay personas registradas.
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-2)" }}>
        {activeRecipients.slice(0, 6).map((r, idx) => (
          <Card
            key={r.id}
            onClick={() => navigate(`/agency/personas/${r.id}`)}
            style={{ display: "flex", alignItems: "center", gap: "var(--space-3)", padding: "var(--space-4)" }}
          >
            <Avatar
              initials={recipientInitials(r)}
              color={AVATAR_COLORS[idx % AVATAR_COLORS.length]}
              size={44}
            />
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ margin: 0, fontWeight: 600, fontSize: "var(--fs-body)" }}>
                {r.preferred_name ?? r.first_name} {r.last_name}
              </p>
              <p style={{ margin: "2px 0 0", fontSize: "var(--fs-caption)", color: "var(--color-ink-soft)" }}>
                {r.room_id ? `Habitación ${r.room_id}` : activeOrganization.type === "RESIDENTIAL_CARE_HOME" ? "Sin habitación asignada" : "Visita a domicilio"}
              </p>
            </div>
            {recipientStatusBadge(r)}
            <ChevronRightIcon size={16} color="var(--color-ink-soft)" />
          </Card>
        ))}
      </div>

      {/* ── GESTIÓN DE TURNOS ─────────────────────────────────────────────── */}
      <SectionHeader title="Gestión de Turnos" to="/agency/turnos" toLabel="Ver todos los turnos" />

      {/* Turnos sin cubrir — alerta prominente */}
      {uncoveredShifts.length > 0 && (
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: 10,
            background: "var(--color-warning-bg)",
            color: "var(--color-warning)",
            borderRadius: "var(--radius-md)",
            padding: "var(--space-3) var(--space-4)",
            marginBottom: "var(--space-3)",
            fontWeight: 600,
          }}
        >
          <AlertIcon size={18} />
          {uncoveredShifts.length === 1
            ? "1 turno sin cubrir"
            : `${uncoveredShifts.length} turnos sin cubrir`}{" "}
          — <Link to="/agency/turnos" style={{ color: "var(--color-warning)", textDecoration: "underline" }}>Gestionar</Link>
        </div>
      )}

      {/* Nota sobre capacidades de API */}
      <div
        style={{
          background: "var(--color-surface-muted)",
          border: "1px dashed var(--color-border)",
          borderRadius: "var(--radius-md)",
          padding: "var(--space-3) var(--space-4)",
          marginBottom: "var(--space-3)",
          fontSize: "var(--fs-caption)",
          color: "var(--color-ink-soft)",
        }}
      >
        <strong>Nota operativa:</strong> Creación de turnos y asignación directa de cuidador requieren endpoints backend no disponibles aún (POST /organizations/:id/shifts, PATCH /organizations/:id/shifts/:id/assign). La visualización de turnos existentes es completamente funcional.
      </div>

      {upcomingShifts.length === 0 && (
        <div
          style={{
            background: "var(--color-surface-muted)",
            borderRadius: "var(--radius-md)",
            padding: "var(--space-6)",
            textAlign: "center",
            color: "var(--color-ink-soft)",
          }}
        >
          No hay turnos próximos registrados.
        </div>
      )}

      <div style={{ display: "flex", flexDirection: "column", gap: "var(--space-2)" }}>
        {upcomingShifts.map((shift) => (
          <Card key={shift.id} style={{ display: "flex", alignItems: "center", gap: "var(--space-3)", padding: "var(--space-4)" }}>
            <div style={{ flex: 1, minWidth: 0 }}>
              <p style={{ margin: 0, fontWeight: 600, fontSize: "var(--fs-body)" }}>
                {formatDate(shift.scheduled_start)}
              </p>
              <p style={{ margin: "2px 0 0", fontSize: "var(--fs-caption)", color: "var(--color-ink-soft)" }}>
                {formatTime(shift.scheduled_start)} – {formatTime(shift.scheduled_end)}
                {shift.care_recipient_id ? ` · Persona #${shift.care_recipient_id.slice(-6)}` : ""}
              </p>
            </div>
            {shiftStatusBadge(shift.status)}
          </Card>
        ))}
      </div>

      {/* ── ACCESOS RÁPIDOS ───────────────────────────────────────────────── */}
      <SectionHeader title="Accesos rápidos" />
      <div style={{ display: "flex", gap: "var(--space-3)", flexWrap: "wrap" }}>
        {[
          { to: "/agency/turnos", label: "Ver todos los turnos" },
          { to: "/agency/personas", label: "Personas / Residentes" },
          { to: "/agency/equipo", label: "Equipo / Cuidadores" },
          { to: "/messages", label: "Mensajes" },
          { to: "/notifications", label: "Notificaciones" },
        ].map(({ to, label }) => (
          <Link
            key={to}
            to={to}
            style={{
              padding: "12px 20px",
              borderRadius: "var(--radius-md)",
              background: "var(--color-surface)",
              border: "1px solid var(--color-border)",
              boxShadow: "var(--shadow-card)",
              color: "var(--color-ink)",
              fontWeight: 600,
              textDecoration: "none",
              fontSize: "var(--fs-body)",
              display: "flex",
              alignItems: "center",
              gap: 6,
            }}
          >
            {label} <ChevronRightIcon size={15} />
          </Link>
        ))}
      </div>
    </div>
  );
}
