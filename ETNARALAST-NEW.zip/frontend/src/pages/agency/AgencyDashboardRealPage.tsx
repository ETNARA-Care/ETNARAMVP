import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { useAuth } from "../../auth/AuthContext";
import { listOrgCareRecipients, getShiftCoverage, listOrgWorkers, type OrgCareRecipient, type CoverageSummary } from "../../api/agency";
import { listMyNotifications } from "../../api/notifications";
import { LoadingState, ErrorState } from "../../components/UiStates";
import { Card } from "../../components/Primitives";

function StatCard({ label, value }: { label: string; value: string | number }) {
  return (
    <Card style={{ flex: "1 1 140px", textAlign: "center" }}>
      <p style={{ fontFamily: "var(--font-display)", fontSize: "var(--fs-display-lg)", color: "var(--color-ink)", margin: "0 0 4px" }}>
        {value}
      </p>
      <p style={{ fontFamily: "var(--font-body)", fontSize: "var(--fs-caption)", color: "var(--color-ink-soft)", margin: 0 }}>{label}</p>
    </Card>
  );
}

export function AgencyDashboardRealPage() {
  const { activeOrganization, user } = useAuth();
  const [recipients, setRecipients] = useState<OrgCareRecipient[] | null>(null);
  const [coverage, setCoverage] = useState<CoverageSummary | null>(null);
  const [workerCount, setWorkerCount] = useState<number | null>(null);
  const [unreadCount, setUnreadCount] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  const organizationId = activeOrganization?.id;

  useEffect(() => {
    if (!organizationId) return;
    let cancelled = false;
    setLoading(true);
    setError(null);
    Promise.all([
      listOrgCareRecipients(organizationId),
      getShiftCoverage(organizationId),
      listOrgWorkers(organizationId),
      listMyNotifications(),
    ])
      .then(([recipientsRes, coverageRes, workersRes, notifsRes]) => {
        if (cancelled) return;
        setRecipients(recipientsRes);
        setCoverage(coverageRes);
        setWorkerCount(workersRes.length);
        setUnreadCount(notifsRes.items.filter((n) => !n.readAt).length);
      })
      .catch(() => !cancelled && setError("No pudimos cargar la información del panel."))
      .finally(() => !cancelled && setLoading(false));
    return () => {
      cancelled = true;
    };
  }, [organizationId]);

  if (!organizationId) return <LoadingState />;
  if (loading) return <LoadingState label="Cargando panel..." />;
  if (error) return <ErrorState description={error} />;

  const activeRecipients = recipients?.filter((r) => r.status === "active").length ?? 0;

  return (
    <div style={{ padding: 24, maxWidth: 960, margin: "0 auto" }}>
      <h1 style={{ fontFamily: "var(--font-display)", fontSize: "var(--fs-display-lg)", color: "var(--color-ink)" }}>
        {activeOrganization?.name}
      </h1>
      <p style={{ fontFamily: "var(--font-body)", fontSize: "var(--fs-body)", color: "var(--color-ink-soft)", marginTop: -8 }}>
        Bienvenido{user?.email ? `, ${user.email}` : ""}. Esto es lo que está ocurriendo hoy.
      </p>

      <div style={{ display: "flex", gap: 12, flexWrap: "wrap", margin: "24px 0" }}>
        <StatCard label="Personas activas bajo cuidado" value={activeRecipients} />
        <StatCard label="Miembros del equipo" value={workerCount ?? "—"} />
        <StatCard label="Turnos cubiertos" value={coverage ? `${coverage.covered}/${coverage.total}` : "—"} />
        <StatCard label="Turnos sin cubrir" value={coverage?.uncovered ?? "—"} />
        <StatCard label="Notificaciones sin leer" value={unreadCount ?? "—"} />
      </div>

      <h2 style={{ fontFamily: "var(--font-display)", fontSize: "var(--fs-title)", color: "var(--color-ink)" }}>Personas bajo cuidado</h2>
      {recipients && recipients.length === 0 && (
        <p style={{ fontFamily: "var(--font-body)", color: "var(--color-ink-soft)" }}>Todavía no hay personas registradas.</p>
      )}
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {recipients?.slice(0, 8).map((r) => (
          <Card key={r.id}>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <span style={{ fontFamily: "var(--font-body)", fontSize: "var(--fs-body)", color: "var(--color-ink)" }}>
                {r.preferred_name ?? r.first_name} {r.last_name}
              </span>
              <span
                style={{
                  fontFamily: "var(--font-mono)",
                  fontSize: "var(--fs-caption)",
                  color: r.status === "active" ? "var(--color-verified)" : "var(--color-ink-soft)",
                }}
              >
                {r.status}
              </span>
            </div>
          </Card>
        ))}
      </div>

      <div style={{ marginTop: 24, display: "flex", gap: 12 }}>
        <Link
          to="/messages"
          style={{
            padding: "10px 18px",
            borderRadius: 10,
            background: "var(--color-ink)",
            color: "#fff",
            fontFamily: "var(--font-body)",
            fontWeight: 600,
            textDecoration: "none",
          }}
        >
          Ir a mensajes
        </Link>
        <Link
          to="/notifications"
          style={{
            padding: "10px 18px",
            borderRadius: 10,
            background: "var(--color-ink-tint)",
            color: "var(--color-ink)",
            fontFamily: "var(--font-body)",
            fontWeight: 600,
            textDecoration: "none",
          }}
        >
          Ver notificaciones
        </Link>
      </div>
    </div>
  );
}
